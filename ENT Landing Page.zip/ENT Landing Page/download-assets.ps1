# Downloads every Figma image used in index.html into ./assets and updates index.html to use them.
# Run from the project folder:  powershell -ExecutionPolicy Bypass -File .\download-assets.ps1
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
if (-not $root) { $root = (Get-Location).Path }
$htmlPath = Join-Path $root "index.html"
$assets = Join-Path $root "assets"
New-Item -ItemType Directory -Force -Path $assets | Out-Null

$utf8 = New-Object System.Text.UTF8Encoding($false)
$html = [System.IO.File]::ReadAllText($htmlPath, $utf8)

$urls = [regex]::Matches($html, 'https://www\.figma\.com/api/mcp/asset/[a-f0-9-]+\.(png|svg)') |
        ForEach-Object { $_.Value } | Select-Object -Unique

foreach ($url in $urls) {
  $name = $url.Split('/')[-1]
  $file = Join-Path $assets $name
  Write-Host "Downloading $name ..."
  Invoke-WebRequest -Uri $url -OutFile $file -UseBasicParsing
  $html = $html.Replace($url, "assets/$name")
}

[System.IO.File]::WriteAllText($htmlPath, $html, $utf8)
Write-Host "Done. $($urls.Count) files saved in the assets folder."
