#!/usr/bin/env bash
# Figma asset URLs expire after 7 days. Run this once (from this folder) to save them locally
# and point index.html at ./assets/.
set -e
mkdir -p assets
grep -o 'https://www.figma.com/api/mcp/asset/[a-f0-9-]*\.\(png\|svg\)' index.html | sort -u | while read -r url; do
  f="assets/$(basename "$url")"
  curl -sSfL "$url" -o "$f" && sed -i.bak "s#$url#$f#g" index.html
done
rm -f index.html.bak
echo "Done: assets saved in ./assets"
